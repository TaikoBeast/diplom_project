import React, { useEffect, useState } from "react";

function CalibrationSchedule() {
    const [data, setData] = useState([]);

    useEffect(() => {
        // Замените URL на ваш API-эндпоинт при необходимости
        fetch("http://localhost:5000/api/calibration-schedule")
            .then((res) => res.json())
            .then((data) => setData(data))
            .catch((err) => console.error("Ошибка загрузки данных:", err));
    }, []);

    return (
        <div style={{ padding: "20px" }}>
            <h2>Годовой график калибровок</h2>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
                <thead>
                    <tr>
                        <th style={thStyle}>№</th>
                        <th style={thStyle}>Назва СІ</th>
                        <th style={thStyle}>Інвентарний №</th>
                        <th style={thStyle}>Дата останньої калібровки</th>
                        <th style={thStyle}>Дата наступної калібровки</th>
                        <th style={thStyle}>Відповідальний</th>
                    </tr>
                </thead>
                <tbody>
                    {data.map((item, idx) => (
                        <tr key={item.id || idx}>
                            <td style={tdStyle}>{idx + 1}</td>
                            <td style={tdStyle}>{item.name}</td>
                            <td style={tdStyle}>{item.inventory_number}</td>
                            <td style={tdStyle}>{item.last_calibration}</td>
                            <td style={tdStyle}>{item.next_calibration}</td>
                            <td style={tdStyle}>{item.responsible}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

const thStyle = {
    border: "1px solid #ccc",
    padding: "8px",
    backgroundColor: "#f2f2f2",
};

const tdStyle = {
    border: "1px solid #ccc",
    padding: "8px",
};

export default CalibrationSchedule;
