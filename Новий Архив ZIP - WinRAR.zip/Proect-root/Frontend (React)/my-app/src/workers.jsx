import React, { useState, useEffect } from 'react';

function Workers() {
  const [employees, setEmployees] = useState([]);
  const [services, setServices] = useState([]);
  const [persons, setPersons] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [currentEmployee, setCurrentEmployee] = useState(null);

  const [formEmployee, setFormEmployee] = useState({
    kod_service: '',
    physical_person: '',
    hireDate: '',
    dismissalDate: '',
    login: ''
  });

  const formatDate = (dateStr) => {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  };

  const fetchEmployees = () => {
    fetch("http://localhost:5000/sel_employees")
      .then(res => res.json())
      .then(data => {
        const formatted = data.map(item => ({
          id: item.id,
          departmentName: item.name_serves,
          fullName: item.name_person,
          hireDate: formatDate(item.date_admission),
          dismissalDate: formatDate(item.date_termination),
          login: item.login
        }));
        setEmployees(formatted);
      })
      .catch(err => console.error("Помилка при завантаженні:", err));
  };

  useEffect(() => {
    fetchEmployees();

    fetch("http://localhost:5000/sel_services")
      .then(res => res.json())
      .then(setServices)
      .catch(err => console.error("Помилка завантаження відділів:", err));

    fetch("http://localhost:5000/sel_physical_persons")
      .then(res => res.json())
      .then(setPersons)
      .catch(err => console.error("Помилка завантаження осіб:", err));
  }, []);

  const handleAdd = () => {
    setFormEmployee({
      kod_service: '',
      physical_person: '',
      hireDate: '',
      dismissalDate: '',
      login: ''
    });
    setIsAdding(true);
    setIsEditing(false);
  };

  const handleEdit = (employee) => {
    const service = services.find(s => s.name_f === employee.departmentName);
    const person = persons.find(p => p.name_f === employee.fullName);

    setFormEmployee({
      kod_service: service?.id || '',
      physical_person: person?.id || '',
      hireDate: employee.hireDate,
      dismissalDate: employee.dismissalDate,
      login: employee.login
    });

    setCurrentEmployee(employee);
    setIsEditing(true);
    setIsAdding(false);
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Ви точно хочете видалити цього працівника?")) return;
    try {
      const res = await fetch(`http://localhost:5000/delete_employees/${id}`, { method: "DELETE" });
      if (res.ok) fetchEmployees();
    } catch (e) {
      console.error("Серверна помилка:", e);
    }
  };

  const handleSave = async () => {
    const url = isAdding
      ? "http://localhost:5000/add_employees"
      : `http://localhost:5000/update_employees/${currentEmployee.id}`;
    const method = isAdding ? "POST" : "PUT";

    try {
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          kod_service: formEmployee.kod_service,
          physical_person: formEmployee.physical_person,
          date_admission: formEmployee.hireDate,
          date_termination: formEmployee.dismissalDate,
          login: formEmployee.login
        })
      });

      if (res.ok) {
        fetchEmployees();
        handleCancel();
      }
    } catch (err) {
      console.error("Серверна помилка:", err);
    }
  };

  const handleCancel = () => {
    setIsAdding(false);
    setIsEditing(false);
    setCurrentEmployee(null);
    setFormEmployee({
      kod_service: '',
      physical_person: '',
      hireDate: '',
      dismissalDate: '',
      login: ''
    });
  };

  const filteredEmployees = employees.filter(emp =>
    emp.fullName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    emp.login?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    emp.departmentName?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div style={pageStyle}>
      <h1 style={titleStyle}>Працівники</h1>

      <div style={buttonGroupStyle}>
        <button onClick={handleAdd} style={addButtonStyle}>Додати</button>
        <button onClick={() => window.history.back()} style={backButtonStyle}>Назад</button>
      </div>

      <div style={searchWrapperStyle}>
        <input
          type="text"
          placeholder="Пошук..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          style={searchInputStyle}
        />
        <span style={searchIconStyle}>🔍</span>
      </div>

      <table style={tableStyle}>
        <thead>
          <tr>
            <th style={thStyle}>№</th>
            <th style={thStyle}>Назва відділа</th>
            <th style={thStyle}>Назва повна</th>
            <th style={thStyle}>Дата прийому</th>
            <th style={thStyle}>Дата звільнення</th>
            <th style={thStyle}>Login</th>
            <th style={thStyle}>Дії</th>
          </tr>
        </thead>
        <tbody>
          {filteredEmployees.map((emp, index) => (
            <tr key={emp.id}>
              <td style={tdStyle}>{index + 1}</td>
              <td style={tdStyle}>{emp.departmentName}</td>
              <td style={tdStyle}>{emp.fullName}</td>
              <td style={tdStyle}>{emp.hireDate}</td>
              <td style={tdStyle}>{emp.dismissalDate}</td>
              <td style={tdStyle}>{emp.login}</td>
              <td style={tdStyle}>
                <button onClick={() => handleEdit(emp)} style={editButtonStyle}>Редагувати</button>
                <button onClick={() => handleDelete(emp.id)} style={deleteButtonStyle}>Видалити</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {(isAdding || isEditing) && (
        <div style={modalOverlayStyle}>
          <div style={modalStyle}>
            <h2>{isAdding ? "Додати працівника" : "Редагувати працівника"}</h2>

            {/* Комбобокс для відділу */}
            <select
              value={formEmployee.kod_service}
              onChange={(e) => setFormEmployee({ ...formEmployee, kod_service: e.target.value })}
              style={inputStyle}
            >
              <option value="">Оберіть відділ</option>
              {services.map(s => (
                <option key={s.id} value={s.id}>{s.name_f}</option>
              ))}
            </select>

            {/* Комбобокс для особи */}
            <select
              value={formEmployee.physical_person}
              onChange={(e) => setFormEmployee({ ...formEmployee, physical_person: e.target.value })}
              style={inputStyle}
            >
              <option value="">Оберіть особу</option>
              {persons.map(p => (
                <option key={p.id} value={p.id}>{p.name_f}</option>
              ))}
            </select>

            <input
              type="date"
              value={formEmployee.hireDate}
              onChange={(e) => setFormEmployee({ ...formEmployee, hireDate: e.target.value })}
              style={inputStyle}
            />
            <input
              type="date"
              value={formEmployee.dismissalDate}
              onChange={(e) => setFormEmployee({ ...formEmployee, dismissalDate: e.target.value })}
              style={inputStyle}
            />
            <input
              placeholder="Login"
              value={formEmployee.login}
              onChange={(e) => setFormEmployee({ ...formEmployee, login: e.target.value })}
              style={inputStyle}
            />

            <div style={{ marginTop: '15px' }}>
              <button onClick={handleSave} style={saveButtonStyle}>Зберегти</button>
              <button onClick={handleCancel} style={cancelButtonStyle}>Скасувати</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}



// Стили (такие же, как в OdiniciVimiru)
const pageStyle = {
  minHeight: '100vh',
  padding: '40px',
  backgroundColor: '#f0f2f5',
  textAlign: 'center',
};

const titleStyle = {
  marginBottom: '20px',
  fontSize: '32px',
};

const buttonGroupStyle = {
  marginBottom: '20px',
  display: 'flex',
  justifyContent: 'center',
  gap: '15px',
};

const addButtonStyle = {
  padding: '10px 20px',
  fontSize: '16px',
  backgroundColor: '#28a745',
  color: 'white',
  border: 'none',
  borderRadius: '5px',
  cursor: 'pointer',
};

const backButtonStyle = {
  padding: '10px 20px',
  fontSize: '16px',
  backgroundColor: '#6c757d',
  color: 'white',
  border: 'none',
  borderRadius: '5px',
  cursor: 'pointer',
};

const searchWrapperStyle = {
  position: 'relative',
  display: 'inline-block',
  marginBottom: '20px',
};

const searchInputStyle = {
  padding: '10px 40px 10px 10px',
  fontSize: '16px',
  width: '300px',
  borderRadius: '5px',
  border: '1px solid #ccc',
};

const searchIconStyle = {
  position: 'absolute',
  right: '10px',
  top: '50%',
  transform: 'translateY(-50%)',
  fontSize: '20px',
  color: '#888',
};

const tableStyle = {
  margin: '0 auto',
  borderCollapse: 'collapse',
  width: '90%',
  backgroundColor: 'white',
  boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
};

const thStyle = {
  padding: '12px',
  borderBottom: '2px solid #dee2e6',
  backgroundColor: '#343a40',
  color: 'white',
  fontSize: '16px',
};

const tdStyle = {
  padding: '12px',
  borderBottom: '1px solid #dee2e6',
  fontSize: '14px',
};

const editButtonStyle = {
  marginRight: '10px',
  padding: '5px 10px',
  backgroundColor: '#007bff',
  color: 'white',
  border: 'none',
  borderRadius: '4px',
  cursor: 'pointer',
};

const deleteButtonStyle = {
  padding: '5px 10px',
  backgroundColor: '#dc3545',
  color: 'white',
  border: 'none',
  borderRadius: '4px',
  cursor: 'pointer',
};

const modalOverlayStyle = {
  position: 'fixed',
  top: 0,
  left: 0,
  right: 0,
  bottom: 0,
  backgroundColor: 'rgba(0, 0, 0, 0.5)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  zIndex: 1000,
};

const modalStyle = {
  backgroundColor: 'white',
  padding: '30px',
  borderRadius: '10px',
  width: '300px',
  minHeight: '350px',
  boxShadow: '0 2px 10px rgba(0,0,0,0.3)',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  textAlign: 'center',
};

const inputStyle = {
  width: '100%',
  padding: '10px',
  fontSize: '16px',
  borderRadius: '5px',
  border: '1px solid #ccc',
  marginBottom: '10px',
};

const saveButtonStyle = {
  padding: '8px 16px',
  backgroundColor: '#28a745',
  color: 'white',
  border: 'none',
  borderRadius: '5px',
  cursor: 'pointer',
};

const cancelButtonStyle = {
  padding: '8px 16px',
  backgroundColor: '#6c757d',
  color: 'white',
  border: 'none',
  borderRadius: '5px',
  cursor: 'pointer',
};

export default Workers;
