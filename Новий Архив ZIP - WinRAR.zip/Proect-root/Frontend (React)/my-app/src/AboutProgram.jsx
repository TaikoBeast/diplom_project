import React from "react";

function AboutProgram() {
  return (
    <div style={pageStyle}>
      <div style={contentStyle}>
        <h1 style={titleStyle}>Про програму</h1>

        <p style={textStyle}>
          <strong>АРМ "Метролог"</strong> – це спеціалізоване програмне забезпечення,
          призначене для автоматизації роботи метрологічних служб підприємств.
          Програма забезпечує облік, контроль і управління засобами вимірювальної техніки (ЗВТ),
          планування повірок, формування звітності та дотримання вимог нормативних документів.
        </p>

        <h2 style={subtitleStyle}>Основні можливості:</h2>

        <div style={sectionStyle}>
          <h3 style={featureTitleStyle}>✅ Учет засобів вимірювань</h3>
          <ul style={listStyle}>
            <li>Ведення реєстру ЗВТ з детальними характеристиками.</li>
            <li>Відстеження статусів (в експлуатації, на повірці, списано).</li>
            <li>Облік інвентарних і заводських номерів.</li>
          </ul>

          <h3 style={featureTitleStyle}>✅ Планування повірок і калібровок</h3>
          <ul style={listStyle}>
            <li>Автоматичне формування графіка повірок.</li>
            <li>Контроль міжповірочних інтервалів.</li>
            <li>Повідомлення про майбутні і прострочені повірки.</li>
          </ul>

          <h3 style={featureTitleStyle}>✅ Формування звітності</h3>
          <ul style={listStyle}>
            <li>Генерація стандартних звітів (акти повірок, реєстри, статистика).</li>
            <li>Підготовка документів для наглядових органів (СМК).</li>
            <li>Експорт даних у Excel, Word, PDF.</li>
          </ul>

          <h3 style={featureTitleStyle}>✅ Нормативне відповідність</h3>
          <ul style={listStyle}>
            <li>Підтримка актуальних ГОСТ, РМГ, методик повірки.</li>
          </ul>
        </div>
      </div>
    </div>
  );
}

// Стили
const pageStyle = {
  padding: "40px 20px",
  backgroundColor: "#f8f9fa",
  minHeight: "100vh",
  display: "flex",
  justifyContent: "center",
};

const contentStyle = {
  maxWidth: "900px",
  backgroundColor: "#ffffff",
  padding: "40px",
  borderRadius: "12px",
  boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
};

const titleStyle = {
  fontSize: "32px",
  marginBottom: "20px",
  color: "#343a40",
};

const subtitleStyle = {
  fontSize: "24px",
  marginTop: "30px",
  marginBottom: "15px",
  color: "#495057",
};

const featureTitleStyle = {
  fontSize: "18px",
  marginTop: "20px",
  marginBottom: "10px",
  color: "#007bff",
};

const textStyle = {
  fontSize: "16px",
  color: "#212529",
  lineHeight: "1.6",
};

const listStyle = {
  paddingLeft: "20px",
  marginBottom: "20px",
  color: "#212529",
  fontSize: "16px",
  lineHeight: "1.5",
};

const sectionStyle = {
  marginTop: "20px",
};

export default AboutProgram;