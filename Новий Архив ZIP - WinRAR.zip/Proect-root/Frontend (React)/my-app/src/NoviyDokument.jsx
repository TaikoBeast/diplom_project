import React from "react";

function NoviyDokument() {
    return (
        <div style={{ padding: "20px" }}>
            <h1>Новий документ</h1>
            <p>Тут будет создание нового документа.</p>
        </div>
    );
}

export default NoviyDokument;
