import React, { useState, useEffect } from 'react';

function OdiniciVimiru() {
  const [units, setUnits] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [currentUnit, setCurrentUnit] = useState(null);
  const [formUnit, setFormUnit] = useState({ fullName: '', shortName: '', note: '' });

  const fetchUnits = () => {
    fetch("http://localhost:5000/sel_ed_izm")
      .then(res => res.json())
      .then(data => {
        const formatted = data.map(item => ({
          id: item.id,
          fullName: item.name_full,
          shortName: item.name_short,
          note: item.note || ''
        }));
        setUnits(formatted);
      })
      .catch(err => console.error("Помилка при завантаженні:", err));
  };

  useEffect(() => {
    fetchUnits();
  }, []);

  const handleDelete = async (id) => {
    if (!window.confirm("Ви точно хочете видалити цю одиницю?")) return;
    try {
      const res = await fetch(`http://localhost:5000/delete_ed_izm/${id}`, { method: "DELETE" });
      if (res.ok) fetchUnits();
      else console.error("Помилка при видаленні");
    } catch (e) {
      console.error("Серверна помилка:", e);
    }
  };

  const handleAdd = () => {
    setFormUnit({ fullName: '', shortName: '', note: '' });
    setIsAdding(true);
    setIsEditing(false);
  };

  const handleEdit = (unit) => {
    setFormUnit({ fullName: unit.fullName, shortName: unit.shortName, note: unit.note });
    setCurrentUnit(unit);
    setIsEditing(true);
    setIsAdding(false);
  };

  const handleSave = async () => {
    const url = isAdding
      ? "http://localhost:5000/add_ed_izm"
      : `http://localhost:5000/update_edS_izm/${currentUnit.id}`;

    const method = isAdding ? "POST" : "PUT";

    try {
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fullName: formUnit.fullName,
          shortName: formUnit.shortName,
          note: formUnit.note
        })
      });
      if (res.ok) {
        fetchUnits();
        handleCancel();
      } else {
        console.error("Помилка збереження");
      }
    } catch (err) {
      console.error("Серверна помилка:", err);
    }
  };

  const handleCancel = () => {
    setIsAdding(false);
    setIsEditing(false);
    setCurrentUnit(null);
    setFormUnit({ fullName: '', shortName: '', note: '' });
  };

  const filteredUnits = units.filter(unit =>
    unit.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    unit.shortName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    unit.note.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div style={pageStyle}>
      <h1 style={titleStyle}>Одиниці вимірювання</h1>

      <div style={buttonGroupStyle}>
        <button onClick={handleAdd} style={addButtonStyle}>Додати</button>
        <button onClick={() => window.history.back()} style={backButtonStyle}>Назад</button>
      </div>

      <div style={searchWrapperStyle}>
        <input
          type="text"
          placeholder="Пошук..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          style={searchInputStyle}
        />
        <span style={searchIconStyle}>🔍</span>
      </div>

      <table style={tableStyle}>
        <thead>
          <tr>
            <th style={thStyle}>№</th>
            <th style={thStyle}>Повна назва</th>
            <th style={thStyle}>Коротка назва</th>
            <th style={thStyle}>Примітка</th>
            <th style={thStyle}>Дії</th>
          </tr>
        </thead>
        <tbody>
          {filteredUnits.map((unit, index) => (
            <tr key={unit.id}>
              <td style={tdStyle}>{index + 1}</td>
              <td style={tdStyle}>{unit.fullName}</td>
              <td style={tdStyle}>{unit.shortName}</td>
              <td style={tdStyle}>{unit.note}</td>
              <td style={tdStyle}>
                <button onClick={() => handleEdit(unit)} style={editButtonStyle}>Редагувати</button>
                <button onClick={() => handleDelete(unit.id)} style={deleteButtonStyle}>Видалити</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {(isAdding || isEditing) && (
        <div style={modalOverlayStyle}>
          <div style={modalStyle}>
            <h2>{isAdding ? "Додати одиницю" : "Редагувати одиницю"}</h2>
            <input
              placeholder="Повна назва"
              value={formUnit.fullName}
              onChange={(e) => setFormUnit({ ...formUnit, fullName: e.target.value })}
              style={inputStyle}
            />
            <input
              placeholder="Коротка назва"
              value={formUnit.shortName}
              onChange={(e) => setFormUnit({ ...formUnit, shortName: e.target.value })}
              style={inputStyle}
            />
            <input
              placeholder="Примітка"
              value={formUnit.note}
              onChange={(e) => setFormUnit({ ...formUnit, note: e.target.value })}
              style={inputStyle}
            />
                <button onClick={handleSave} style={saveButtonStyle}>Зберегти</button>
                <button onClick={handleCancel} style={cancelButtonStyle}>Скасувати</button>
          </div>
        </div>
      )}
    </div>
  );
}


// Стили
const pageStyle = {
    minHeight: '100vh',
    padding: '40px',
    backgroundColor: '#f0f2f5',
    textAlign: 'center',
};

const titleStyle = {
    marginBottom: '20px',
    fontSize: '32px',
};

const buttonGroupStyle = {
    marginBottom: '20px',
    display: 'flex',
    justifyContent: 'center',
    gap: '15px',
};

const addButtonStyle = {
    padding: '10px 20px',
    fontSize: '16px',
    backgroundColor: '#28a745',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
};

const backButtonStyle = {
    padding: '10px 20px',
    fontSize: '16px',
    backgroundColor: '#6c757d',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
};

const searchWrapperStyle = {
    position: 'relative',
    display: 'inline-block',
    marginBottom: '20px',
};

const searchInputStyle = {
    padding: '10px 40px 10px 10px',
    fontSize: '16px',
    width: '300px',
    borderRadius: '5px',
    border: '1px solid #ccc',
};

const searchIconStyle = {
    position: 'absolute',
    right: '10px',
    top: '50%',
    transform: 'translateY(-50%)',
    fontSize: '20px',
    color: '#888',
};

const tableStyle = {
    margin: '0 auto',
    borderCollapse: 'collapse',
    width: '80%',
    backgroundColor: 'white',
    boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
};

const thStyle = {
    padding: '12px',
    borderBottom: '2px solid #dee2e6',
    backgroundColor: '#343a40',
    color: 'white',
    fontSize: '16px',
};

const tdStyle = {
    padding: '12px',
    borderBottom: '1px solid #dee2e6',
    fontSize: '14px',
};

const editButtonStyle = {
    marginRight: '10px',
    padding: '5px 10px',
    backgroundColor: '#007bff',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
};

const deleteButtonStyle = {
    padding: '5px 10px',
    backgroundColor: '#dc3545',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
};

const highlightRowStyle = {
    backgroundColor: '#d4edda',
};

const modalOverlayStyle = {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1000,
};

const modalStyle = {
    backgroundColor: 'white',
    padding: '30px',
    borderRadius: '10px',
    width: '300px',
    minHeight: '350px',
    boxShadow: '0 2px 10px rgba(0,0,0,0.3)',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    textAlign: 'center',
};

const inputStyle = {
    width: '100%',
    padding: '10px',
    fontSize: '16px',
    borderRadius: '5px',
    border: '1px solid #ccc',
    marginBottom: '10px',
};

const saveButtonStyle = {
    padding: '8px 16px',
    backgroundColor: '#28a745',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
};

const cancelButtonStyle = {
    padding: '8px 16px',
    backgroundColor: '#6c757d',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
};



export default OdiniciVimiru;