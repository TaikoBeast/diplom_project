import { Routes, Route } from "react-router-dom";
import Login from "./Login";
import Dashboard from "./Dashboard";
import NoviyZasib from "./NoviyZasib";
import Zhurnal from "./Zhurnal";
import NoviyDokument from "./NoviyDokument";
import OdiniciVimiru from "./OdiniciVimiru";
import AccuracyClass from "./accuracy_class";
import Category from "./category";
import Enterprise from "./enterprise";
import Individuals from "./individuals";
import Location from "./location";
import Manufacturer from "./manufacturer";
import Setings from "./setings"; // ✅ заглавная буква
import Servis from "./servis";
import Stats from "./stats";     // ✅ заглавная буква
import TypesOfMeasurements from "./types_of_measurements";
import TypeOfVerification from "./type_of_verification";
import VerificationLocation from "./verification_location";
import VerificationMethod from "./verification_method";
import Workers from "./workers";
import Reports from "./Reports";
import CalibrationSchedule from "./CalibrationSchedule";
import VvodEkspluat from './VvodEkspluat'
import AboutProgram from "./AboutProgram";
import GrafikPovirok from "./GrafikPovirok";

function App() {
    return (
        <Routes>
            <Route path="/" element={<Login />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/AboutProgram" element={<AboutProgram />} /> 
            <Route path="/VvodEkspluat" element={<VvodEkspluat />} />
            <Route path="/noviy-zasib" element={<NoviyZasib />} />
            <Route path="/zhurnal" element={<Zhurnal />} />
            <Route path="/noviy-dokument" element={<NoviyDokument />} />
            <Route path="/odunitsya-vimiru" element={<OdiniciVimiru />} />

            <Route path="/accuracy_class" element={<AccuracyClass />} />
            <Route path="/category" element={<Category />} />
            <Route path="/enterprise" element={<Enterprise />} />
            <Route path="/individuals" element={<Individuals />} />
            <Route path="/location" element={<Location />} />
            <Route path="/manufacturer" element={<Manufacturer />} />
            <Route path="/setings" element={<Setings />} />     {/* ✅ исправлено */}
            <Route path="/servis" element={<Servis />} />
            <Route path="/stats" element={<Stats />} />         {/* ✅ исправлено */}
            <Route path="/types_of_measurements" element={<TypesOfMeasurements />} />
            <Route path="/type_of_verification" element={<TypeOfVerification />} />
            <Route path="/verification_location" element={<VerificationLocation />} />
            <Route path="/verification_method" element={<VerificationMethod />} />
            <Route path="/workers" element={<Workers />} />

            <Route path="/reports" element={<Reports />} />
            <Route path="/reports/kalybrovka" element={<CalibrationSchedule />} />
            <Route path="/reports/grafikPovirok" element={<GrafikPovirok />} />
        </Routes>
    );
}

export default App;
