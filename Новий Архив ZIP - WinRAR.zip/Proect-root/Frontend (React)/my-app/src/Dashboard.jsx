import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

function Dashboard() {
    const navigate = useNavigate();
    const username = localStorage.getItem('username');
    const [activeDropdown, setActiveDropdown] = useState(null);

    const handleLogout = () => {
        localStorage.removeItem('username');
        localStorage.removeItem('token');
        navigate('/');
    };

    const toggleDropdown = (menu) => {
        setActiveDropdown((prev) => (prev === menu ? null : menu));
    };

    return (
        <div style={{ minHeight: "100vh", backgroundColor: "#fff", display: "flex", flexDirection: "column" }}>
            <header style={headerStyle}>
                <div style={logoStyle}>Автоматизоване робоче місце метролога</div>
                <nav style={navStyle}>
                    <button style={navButtonStyle} onClick={() => navigate("/AboutProgram")}>О програмі</button>

                    <DropdownMenu
                        label="Довідники"
                        isOpen={activeDropdown === "dovidnyky"}
                        onClick={() => toggleDropdown("dovidnyky")}
                        items={[
                            { label: "Одиниці вимірювання", path: "/odunitsya-vimiru" },
                            { label: "Співробітники", path: "/workers" },
                            { label: "Сервіс", path: "/servis" },
                            { label: "Підприємство", path: "/enterprise" },
                            { label: "Виробник", path: "/manufacturer" },
                            { label: "Клас точності", path: "/accuracy_class" },
                            { label: "Фізичні особи", path: "/individuals" },
                            { label: "Параметр", path: "/setings" },
                            { label: "Стан", path: "/stats" },
                            { label: "Категорії", path: "/category" },
                            { label: "Види вимірювань", path: "/types_of_measurements" },
                            { label: "Вид поверки", path: "/type_of_verification" },
                            { label: "Місце повірки", path: "/verification_location" },
                            { label: "Методика повірки", path: "/verification_method" },
                            { label: "Місцезнаходження", path: "/location" }
                        ]}
                        navigate={navigate}
                    />

                    <DropdownMenu
                        label="Документи"
                        isOpen={activeDropdown === "dokumenty"}
                        onClick={() => toggleDropdown("dokumenty")}
                        items={[
                            { label: "Ввод в експлуатацію", path: "/vvodEkspluat" },
                            { label: "Переміщення ЗВТ", path: "/peremischennya" },
                            { label: "Списання ЗВТ", path: "/spysannya" },
                            { label: "Ремонт ЗВТ", path: "/remont" },
                            { label: "Калібровка ЗВТ", path: "/kalibrovka" },
                            { label: "Повірка ЗВТ", path: "/poverka" },
                            { label: "Розпломбування", path: "/rasplombuvannya" },
                            { label: "Опломбування", path: "/oplombuvannya" },
                            { label: "Зміна відповідального", path: "/zmina_vidpovidalnogo" }
                        ]}
                        navigate={navigate}
                    />

                    <button style={navButtonStyle} onClick={() => { setActiveDropdown(null); navigate("/zhurnal"); }}>
                        Планування
                    </button>

                    <DropdownMenu
                        label="Звіт"
                        isOpen={activeDropdown === "zvit"}
                        onClick={() => toggleDropdown("zvit")}
                        items={[
                            { label: "Годовой график калибровок", path: "/reports/kalybrovka-year" },
                            { label: "Годовой график поверок", path: "/reports/poverka-year" },
                            { label: "График по видам измерений", path: "/reports/graph-types" },
                            { label: "Реестр средств измерений", path: "/reports/reestr" },
                            { label: "Отчет по неисправным", path: "/reports/neispravnosti" },
                            { label: "Отчет по перемещению СИ", path: "/reports/move" },
                            { label: "Графік повірок", path: "/reports/grafikPovirok" },
                            { label: "Просроченные поверки", path: "/reports/overdue" },
                            { label: "Акт выполненных поверок", path: "/reports/acts" },
                            { label: "Статистика выполнения поверок", path: "/reports/stat-poverok" },
                            { label: "Журнал учета методик поверки", path: "/reports/methods" },
                            { label: "Отчет по стандартам и НД", path: "/reports/norms" },
                            { label: "Статистика отказов СИ", path: "/reports/fails" },
                            { label: "Анализ загруженности метрологічної служби", path: "/reports/load" },
                            { label: "Отчет по затратам на поверку", path: "/reports/costs" },
                            { label: "Отчеты по заявкам на поверку", path: "/reports/requests" }
                        ]}
                        navigate={navigate}
                    />

                    {username && (
                        <DropdownMenu
                            label={`👤 ${username}`}
                            isOpen={activeDropdown === "user"}
                            onClick={() => toggleDropdown("user")}
                            items={[
                                { label: "Вийти", onClick: handleLogout }
                            ]}
                            navigate={navigate}
                        />
                    )}
                </nav>
            </header>

            <main style={{ flex: 1, position: "relative" }}>
    <img
        src="/react2.png"
        alt="Dashboard"
        style={{
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            objectFit: "cover",
        }}
    />
</main>

        </div>
    );
}

function DropdownMenu({ label, isOpen, onClick, items, navigate }) {
    return (
        <div style={{ position: "relative" }}>
            <button style={navButtonStyle} onClick={onClick}>
                {label} ▼
            </button>
            {isOpen && (
                <div style={dropdownMenuStyle}>
                    {items.map((item, index) => (
                        <button
                            key={index}
                            style={dropdownItemStyle}
                            onClick={() => {
                                onClick();
                                item.onClick ? item.onClick() : navigate(item.path);
                            }}
                        >
                            {item.label}
                        </button>
                    ))}
                </div>
            )}
        </div>
    );
}

const headerStyle = {
    backgroundColor: "#2C2C2C",
    color: "#FFFFFF",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "10px 30px",
    position: "relative",
    zIndex: 10,
};

const logoStyle = {
    fontSize: "22px",
    fontWeight: "bold",
};

const navStyle = {
    display: "flex",
    gap: "20px",
    alignItems: "center",
    position: "relative",
};

const navButtonStyle = {
    backgroundColor: "transparent",
    border: "none",
    color: "#FFFFFF",
    fontSize: "16px",
    cursor: "pointer",
    padding: "8px 16px",
    transition: "background 0.3s",
    display: "flex",
    alignItems: "center",
    gap: "5px",
};

const dropdownMenuStyle = {
    position: "absolute",
    top: "40px",
    left: "0",
    backgroundColor: "#333",
    borderRadius: "8px",
    boxShadow: "0 4px 8px rgba(0,0,0,0.2)",
    padding: "10px",
    display: "flex",
    flexDirection: "column",
    minWidth: "250px",
    zIndex: 10,
};

const dropdownItemStyle = {
    background: "transparent",
    border: "none",
    color: "#fff",
    fontSize: "14px",
    textAlign: "left",
    padding: "10px 20px",
    cursor: "pointer",
    width: "100%",
    transition: "background 0.2s ease",
};

const titleStyle = {
    textAlign: "center",
    fontSize: "32px",
    color: "#333",
};

export default Dashboard;