import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const sectionStyle = {
  backgroundColor: 'white',
  borderRadius: '10px',
  padding: '15px',
  marginBottom: '20px',
  boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
};

// Новый стиль контейнера для двух колонок
const twoColumnContainer = {
  display: 'flex',
  flexWrap: 'wrap',
  gap: '15px',
};

// Новый стиль для каждого поля (чтобы занять ~ половину ширины контейнера)
const fieldWrapper = {
  flex: '1 1 48%', // растёт, сжимается, базовая ширина 48%
  minWidth: '250px', // минимальная ширина для адекватного вида на маленьких экранах
  boxSizing: 'border-box',
};

const modalOverlay = {
  position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
  backgroundColor: 'rgba(0, 0, 0, 0.5)', display: 'flex',
  justifyContent: 'center', alignItems: 'center', zIndex: 1000
};

const modalContent = {
  backgroundColor: 'white', padding: '20px', borderRadius: '10px',
  width: '300px', boxShadow: '0 4px 12px rgba(0,0,0,0.3)'
};

const VvodEkspluat = () => {
  const navigate = useNavigate();
  const [formDoc, setFormDoc] = useState({});
  const [activeModal, setActiveModal] = useState(null);
  const [newValue, setNewValue] = useState('');
  const [comboOptions, setComboOptions] = useState({
    naim_si: ['СИ-1', 'СИ-2'],
    tip_si: ['Тип-1', 'Тип-2'],
    kod_si: ['001', '002'],
    kategoriya_si: ['A', 'B'],
    vid_izm: ['Длина', 'Масса'],
    sfera_primeneniya: ['Промышленность', 'Медицина'],
    mesto_nahozhdeniya: ['Склад', 'Цех'],
    otvetstvenniy: ['Иванов И.И.', 'Петров П.П.'],
    sostoyanie_si: ['Исправен', 'Неисправен'],
    primechaniya: ['-', 'Требует поверки'],
    verification_status: ['пройден', 'не пройден'],
    mesto_poverki: ['Лаборатория 1', 'Лаборатория 2'],
    vid_poverki: ['Первичная', 'Периодическая'],
    metodika_poverki: ['М1', 'М2'],
    fio_poveritelya: ['Сидоров С.С.', 'Кузнецова К.К.'],
    zaklyuchenie: ['Соответствует', 'Не соответствует'],
    factory_number: [],
    passport: [],
    inventory_number: [],
    manufacturer: [],
    interval: []
  });

  const openModal = (field) => {
    setActiveModal(field);
    setNewValue('');
  };

  const handleAddValue = () => {
    if (newValue.trim() !== '') {
      setComboOptions((prev) => ({
        ...prev,
        [activeModal]: [...(prev[activeModal] || []), newValue]
      }));
      setFormDoc((prev) => ({
        ...prev,
        [activeModal]: newValue
      }));
      setActiveModal(null);
      setNewValue('');
    }
  };

  // Обновленные версии selectField, textField и dateField с обёрткой для двух колонок
  const selectField = (label, key) => (
    <div style={fieldWrapper} key={key}>
      <label>{label}</label>
      <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
        <select
          value={formDoc[key] || ''}
          onChange={(e) => setFormDoc({ ...formDoc, [key]: e.target.value })}
          style={{ flex: 1, padding: '8px' }}
        >
          <option value="">{label}</option>
          {(comboOptions[key] || []).map((opt, idx) => (
            <option key={idx} value={opt}>{opt}</option>
          ))}
        </select>
        <button onClick={() => openModal(key)} style={{ padding: '5px 10px' }}>＋</button>
      </div>
    </div>
  );

  const textField = (label, key) => (
    <div style={fieldWrapper} key={key}>
      <label>{label}</label>
      <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
        <input
          type="text"
          placeholder={label}
          value={formDoc[key] || ''}
          onChange={(e) => setFormDoc({ ...formDoc, [key]: e.target.value })}
          style={{ flex: 1, padding: '8px' }}
        />
        <button onClick={() => openModal(key)} style={{ padding: '5px 10px' }}>＋</button>
      </div>
    </div>
  );

  const dateField = (label, key) => (
    <div style={fieldWrapper} key={key}>
      <label>{label}</label>
      <input
        type="date"
        value={formDoc[key] || ''}
        onChange={(e) => setFormDoc({ ...formDoc, [key]: e.target.value })}
        style={{ width: '100%', padding: '8px' }}
      />
    </div>
  );

  return (
    <div style={{ padding: '40px', backgroundColor: '#f0f2f5' }}>
      <h2 style={{ textAlign: 'center', fontSize: '32px', marginBottom: '20px' }}>Ввод нового СИ</h2>
      <div style={{ display: 'flex', justifyContent: 'center', gap: '15px', marginBottom: '30px' }}>
        <button
          style={{ padding: '10px 20px', backgroundColor: '#28a745', color: 'white', border: 'none', borderRadius: '5px' }}
        >
          Добавить
        </button>
        <button
          onClick={() => navigate(-1)}
          style={{ padding: '10px 20px', backgroundColor: '#6c757d', color: 'white', border: 'none', borderRadius: '5px' }}
        >
          Закрыть
        </button>
      </div>

      {/* Основные данные */}
      <fieldset style={sectionStyle}>
        <legend><b>Основные данные</b></legend>
        <div style={twoColumnContainer}>
          {selectField('Наименование СИ', 'naim_si')}
          {selectField('Тип СИ', 'tip_si')}
          {selectField('Код СИ', 'kod_si')}
          {selectField('Категория СИ', 'kategoriya_si')}
          {selectField('Вид измерения', 'vid_izm')}
          {selectField('Сфера применения', 'sfera_primeneniya')}
          {selectField('Место нахождения', 'mesto_nahozhdeniya')}
          {selectField('Ответственный', 'otvetstvenniy')}
          {selectField('Состояние СИ', 'sostoyanie_si')}
          {selectField('Примечания', 'primechaniya')}
        </div>
      </fieldset>

      {/* Паспортные данные */}
      <fieldset style={sectionStyle}>
        <legend><b>Паспортные данные</b></legend>
        <div style={twoColumnContainer}>
          {textField('Заводской номер', 'factory_number')}
          {textField('Паспорт №', 'passport')}
          {textField('Инвентарный номер', 'inventory_number')}
          {textField('Изготовитель', 'manufacturer')}
          {dateField('Дата изготовления', 'date_produced')}
          {dateField('Дата ввода в эксплуатацию', 'date_doc')}
        </div>
      </fieldset>

      {/* Поверка */}
      <fieldset style={sectionStyle}>
        <legend><b>Поверка</b></legend>
        <div style={twoColumnContainer}>
          {dateField('Дата после поверки', 'date_last')}
          {textField('Межповерочный интервал', 'interval')}
          {dateField('Дата следующей поверки', 'date_next')}
          {selectField('Статус поверки', 'verification_status')}
          {selectField('Место поверки', 'mesto_poverki')}
          {selectField('Вид поверки', 'vid_poverki')}
          {selectField('Методика поверки', 'metodika_poverki')}
          {selectField('Ф.И.О. поверителя', 'fio_poveritelya')}
          {selectField('Заключение', 'zaklyuchenie')}
        </div>
      </fieldset>

      {/* Модалка */}
      {activeModal && (
        <div style={modalOverlay}>
          <div style={modalContent}>
            <h3>Добавить значение: {activeModal}</h3>
            <input
              type="text"
              placeholder="Введите значение"
              value={newValue}
              onChange={(e) => setNewValue(e.target.value)}
              style={{ width: '100%', padding: '8px', marginBottom: '10px' }}
            />
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <button onClick={() => setActiveModal(null)} style={{ padding: '8px 16px', backgroundColor: '#dc3545', color: 'white', border: 'none', borderRadius: '5px' }}>
                Отмена
              </button>
              <button onClick={handleAddValue} style={{ padding: '8px 16px', backgroundColor: '#28a745', color: 'white', border: 'none', borderRadius: '5px' }}>
                Добавить
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// ==== СТИЛІ ====

const pageStyle = {
  minHeight: '100vh',
  padding: '40px',
  backgroundColor: '#f0f2f5',
  textAlign: 'center',
};

const titleStyle = {
  marginBottom: '20px',
  fontSize: '32px',
};

const buttonGroupStyle = {
  marginBottom: '20px',
  display: 'flex',
  justifyContent: 'center',
  gap: '15px',
};

const addButtonStyle = {
  padding: '10px 20px',
  fontSize: '16px',
  backgroundColor: '#28a745',
  color: 'white',
  border: 'none',
  borderRadius: '5px',
  cursor: 'pointer',
};

const backButtonStyle = {
  padding: '10px 20px',
  fontSize: '16px',
  backgroundColor: '#6c757d',
  color: 'white',
  border: 'none',
  borderRadius: '5px',
  cursor: 'pointer',
};

const inputStyle = {
  width: '100%',
  padding: '10px',
  fontSize: '16px',
  borderRadius: '5px',
  border: '1px solid #ccc',
  marginBottom: '10px',
};

const tableStyle = {
  margin: '0 auto',
  borderCollapse: 'collapse',
  width: '100%',
  backgroundColor: 'white',
  boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
};

const fieldsetStyle = {
  marginBottom: '20px',
  padding: '20px',
  border: '1px solid #ccc',
  borderRadius: '10px',
  textAlign: 'left',
};

export default VvodEkspluat;