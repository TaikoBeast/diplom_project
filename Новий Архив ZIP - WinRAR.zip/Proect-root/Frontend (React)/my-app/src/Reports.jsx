import React from "react";

function Report() {
    return (
        <div style={containerStyle}>
            <h1 style={titleStyle}>Звіти</h1>
            <div style={buttonContainerStyle}>
                <button style={buttonStyle}>Годовой график калибровок</button>
                <button style={buttonStyle}>Годовой график поверок</button>
                <button style={buttonStyle}>График по видам измерений</button>
            </div>
        </div>
    );
}

const containerStyle = {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    minHeight: "100vh",
    backgroundColor: "#f4f4f4",
    padding: "40px 20px",
};

const titleStyle = {
    fontSize: "32px",
    marginBottom: "30px",
    color: "#333",
};

const buttonContainerStyle = {
    display: "flex",
    flexDirection: "column",
    gap: "20px",
    width: "100%",
    maxWidth: "400px",
};

const buttonStyle = {
    padding: "15px 20px",
    fontSize: "16px",
    backgroundColor: "#2C2C2C",
    color: "#fff",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
    transition: "background 0.3s",
};

export default Report;
