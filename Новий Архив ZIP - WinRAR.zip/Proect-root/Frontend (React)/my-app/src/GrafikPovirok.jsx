import React from 'react';

const GrafikPovirok = () => {
  const data = [
    {
      id: 1,
      category: '50',
      name: 'Вагонні тензометричні ваги\n20130BB-15ОЭ № 1, №058',
      accuracy: 'ср.',
      range: '150т',
      dates: '31.08.2023 П\n06.12.2023 ОП\nдо 08.01.2027',
      place: 'ДЗМД',
      months: ['','','','П','','','','','','','','ОП'],
      code: '4020110',
    }
  ];

  const monthLabels = ['Січень','Лютий','Березень','Квітень','Травень','Червень','Липень','Серпень','Вересень','Жовтень','Листопад','Грудень'];

  return (
    <div style={{ overflowX: 'auto', padding: '20px', backgroundColor: '#f8fafc' }}>
      <h2 style={{ textAlign: 'center', marginBottom: '20px' }}>Графік повірок ЗВТ</h2>
      <table style={{ borderCollapse: 'collapse', width: '100%', minWidth: '1400px', backgroundColor: 'white', boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}>
        <thead>
          <tr style={{ backgroundColor: '#e2e8f0' }}>
            <th rowSpan={2} style={thStyle}>№ з/п</th>
            <th rowSpan={2} style={thStyle}>Категорія ЗВТ</th>
            <th rowSpan={2} style={thStyle}>Найменування та умовне позначення ЗВТ</th>
            <th colSpan={2} style={thStyle}>Метрологічні характеристики</th>
            <th rowSpan={2} style={thStyle}>Дата останньої повірки</th>
            <th rowSpan={2} style={thStyle}>Місце проведення повірки</th>
            <th colSpan={12} style={thStyle}>Підлягає повірці за місяцями у 2025 році (од.)</th>
            <th rowSpan={2} style={thStyle}>Код ЗВТ відповідно до номенклатури</th>
          </tr>
          <tr style={{ backgroundColor: '#f1f5f9' }}>
            <th style={thStyle}>клас точності, похибка</th>
            <th style={thStyle}>діапазон вимірювань</th>
            {monthLabels.map((month, idx) => (
              <th key={idx} style={thStyle}>{month}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.map((row, idx) => (
            <tr key={row.id}>
              <td style={tdStyle}>{idx + 1}</td>
              <td style={tdStyle}>{row.category}</td>
              <td style={tdStyle}>{row.name.split('\n').map((line, i) => <div key={i}>{line}</div>)}</td>
              <td style={tdStyle}>{row.accuracy}</td>
              <td style={tdStyle}>{row.range}</td>
              <td style={tdStyle}>{row.dates.split('\n').map((line, i) => <div key={i}>{line}</div>)}</td>
              <td style={tdStyle}>{row.place}</td>
              {row.months.map((val, i) => (
                <td key={i} style={tdStyle}>{val}</td>
              ))}
              <td style={tdStyle}>{row.code}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

const thStyle = {
  border: '1px solid #cbd5e1',
  padding: '8px',
  textAlign: 'center',
  fontWeight: 'bold',
  whiteSpace: 'nowrap',
};

const tdStyle = {
  border: '1px solid #e2e8f0',
  padding: '8px',
  textAlign: 'center',
  verticalAlign: 'middle',
  whiteSpace: 'pre-wrap',
};

export default GrafikPovirok;