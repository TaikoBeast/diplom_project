import React, { useState, useEffect } from 'react';

function Manufacturer() {
    const [manufacturers, setManufacturers] = useState([]);
    const [isEditing, setIsEditing] = useState(false);
    const [isAdding, setIsAdding] = useState(false);
    const [currentManufacturer, setCurrentManufacturer] = useState(null);
    const [newManufacturer, setNewManufacturer] = useState({ name: '', address: '', phone: '', email: '', note: '' });
    const [searchTerm, setSearchTerm] = useState('');

    const fetchManufacturers = () => {
        fetch("http://localhost:5000/sel_manufacturers")
            .then(res => res.json())
            .then(data => setManufacturers(data))
            .catch(err => console.error("Помилка при завантаженні виробників:", err));
    };

    useEffect(() => {
        fetchManufacturers();
    }, []);

    const handleEditClick = (manufacturer) => {
        setIsEditing(true);
        setCurrentManufacturer(manufacturer);
        setNewManufacturer({ ...manufacturer });
    };

    const handleDeleteClick = async (id) => {
        const confirmDelete = window.confirm(`Ви точно хочете видалити виробника №${id}?`);
        if (!confirmDelete) return;

        const res = await fetch(`http://localhost:5000/delete_manufacturer/${id}`, {
            method: 'DELETE'
        });
        if (res.ok) fetchManufacturers();
        else console.error("Помилка при видаленні виробника");
    };

    const handleSaveEdit = async () => {
        const res = await fetch(`http://localhost:5000/update_manufacturer/${currentManufacturer.id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(newManufacturer)
        });
        if (res.ok) fetchManufacturers();
        setIsEditing(false);
        setCurrentManufacturer(null);
    };

    const handleSaveNew = async () => {
        const res = await fetch("http://localhost:5000/add_manufacturer", {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(newManufacturer)
        });
        if (res.ok) fetchManufacturers();
        setIsAdding(false);
        setNewManufacturer({ name: '', address: '', phone: '', email: '', note: '' });
    };

    const handleCancel = () => {
        setIsEditing(false);
        setIsAdding(false);
        setCurrentManufacturer(null);
        setNewManufacturer({ name: '', address: '', phone: '', email: '', note: '' });
    };

    const handleAdd = () => {
        setIsAdding(true);
        setNewManufacturer({ name: '', address: '', phone: '', email: '', note: '' });
    };

    const handleGoBack = () => {
        window.history.back();
    };

    const filteredManufacturers = manufacturers.filter(m =>
        m.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        m.address.toLowerCase().includes(searchTerm.toLowerCase()) ||
        m.phone.toLowerCase().includes(searchTerm.toLowerCase()) ||
        m.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        m.note.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div style={pageStyle}>
            <h1 style={titleStyle}>Виробники</h1>

            <div style={buttonGroupStyle}>
                <button onClick={handleAdd} style={addButtonStyle}>Додати виробника</button>
                <button onClick={handleGoBack} style={backButtonStyle}>Назад</button>
            </div>

            <div style={searchWrapperStyle}>
                <input
                    type="text"
                    placeholder="Пошук..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    style={searchInputStyle}
                />
                <span style={searchIconStyle}>🔍</span>
            </div>

            <table style={tableStyle}>
                <thead>
                    <tr>
                        <th style={thStyle}>№</th>
                        <th style={thStyle}>Назва</th>
                        <th style={thStyle}>Адреса</th>
                        <th style={thStyle}>Телефон</th>
                        <th style={thStyle}>Email</th>
                        <th style={thStyle}>Примітка</th>
                        <th style={thStyle}>Дії</th>
                    </tr>
                </thead>
                <tbody>
                    {filteredManufacturers.map((m, index) => {
                        const isMatch = searchTerm &&
                            (m.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            m.address.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            m.phone.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            m.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            m.note.toLowerCase().includes(searchTerm.toLowerCase()));

                        return (
                            <tr key={m.id} style={isMatch ? highlightRowStyle : {}}>
                                <td style={tdStyle}>{index + 1}</td>
                                <td style={tdStyle}>{m.name}</td>
                                <td style={tdStyle}>{m.address}</td>
                                <td style={tdStyle}>{m.phone}</td>
                                <td style={tdStyle}>{m.email}</td>
                                <td style={tdStyle}>{m.note}</td>
                                <td style={tdStyle}>
                                    <button onClick={() => handleEditClick(m)} style={editButtonStyle}>Редагувати</button>
                                    <button onClick={() => handleDeleteClick(m.id)} style={deleteButtonStyle}>Видалити</button>
                                </td>
                            </tr>
                        );
                    })}
                </tbody>
            </table>

            {(isEditing || isAdding) && (
                <div style={modalOverlayStyle}>
                    <div style={modalStyle}>
                        <h2 style={{ marginBottom: '20px' }}>
                            {isEditing ? 'Редагувати виробника' : 'Додати виробника'}
                        </h2>

                        <input
                            type="text"
                            placeholder="Назва"
                            value={newManufacturer.name}
                            onChange={(e) => setNewManufacturer({ ...newManufacturer, name: e.target.value })}
                            style={inputStyle}
                        />
                        <input
                            type="text"
                            placeholder="Адреса"
                            value={newManufacturer.address}
                            onChange={(e) => setNewManufacturer({ ...newManufacturer, address: e.target.value })}
                            style={inputStyle}
                        />
                        <input
                            type="text"
                            placeholder="Телефон"
                            value={newManufacturer.phone}
                            onChange={(e) => setNewManufacturer({ ...newManufacturer, phone: e.target.value })}
                            style={inputStyle}
                        />
                        <input
                            type="text"
                            placeholder="Email"
                            value={newManufacturer.email}
                            onChange={(e) => setNewManufacturer({ ...newManufacturer, email: e.target.value })}
                            style={inputStyle}
                        />
                        <input
                            type="text"
                            placeholder="Примітка"
                            value={newManufacturer.note}
                            onChange={(e) => setNewManufacturer({ ...newManufacturer, note: e.target.value })}
                            style={inputStyle}
                        />

                        <div style={{ marginTop: '20px', display: 'flex', justifyContent: 'center', gap: '15px' }}>
                            <button onClick={isEditing ? handleSaveEdit : handleSaveNew} style={saveButtonStyle}>Зберегти</button>
                            <button onClick={handleCancel} style={cancelButtonStyle}>Скасувати</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}

// Стили
const pageStyle = {
    minHeight: '100vh',
    padding: '40px',
    backgroundColor: '#f0f2f5',
    textAlign: 'center',
};

const titleStyle = {
    marginBottom: '20px',
    fontSize: '32px',
};

const buttonGroupStyle = {
    marginBottom: '20px',
    display: 'flex',
    justifyContent: 'center',
    gap: '15px',
};

const addButtonStyle = {
    padding: '10px 20px',
    fontSize: '16px',
    backgroundColor: '#28a745',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
};

const backButtonStyle = {
    padding: '10px 20px',
    fontSize: '16px',
    backgroundColor: '#6c757d',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
};

const searchWrapperStyle = {
    position: 'relative',
    display: 'inline-block',
    marginBottom: '20px',
};

const searchInputStyle = {
    padding: '10px 40px 10px 10px',
    fontSize: '16px',
    width: '300px',
    borderRadius: '5px',
    border: '1px solid #ccc',
};

const searchIconStyle = {
    position: 'absolute',
    right: '10px',
    top: '50%',
    transform: 'translateY(-50%)',
    fontSize: '20px',
    color: '#888',
};

const tableStyle = {
    margin: '0 auto',
    borderCollapse: 'collapse',
    width: '90%',
    backgroundColor: 'white',
    boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
};

const thStyle = {
    padding: '12px',
    borderBottom: '2px solid #dee2e6',
    backgroundColor: '#343a40',
    color: 'white',
    fontSize: '16px',
};

const tdStyle = {
    padding: '12px',
    borderBottom: '1px solid #dee2e6',
    fontSize: '14px',
};

const editButtonStyle = {
    marginRight: '10px',
    padding: '5px 10px',
    backgroundColor: '#007bff',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
};

const deleteButtonStyle = {
    padding: '5px 10px',
    backgroundColor: '#dc3545',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
};

const highlightRowStyle = {
    backgroundColor: '#d4edda',
};

const modalOverlayStyle = {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1000,
};

const modalStyle = {
    backgroundColor: 'white',
    padding: '30px',
    borderRadius: '10px',
    width: '300px',
    minHeight: '400px',
    boxShadow: '0 2px 10px rgba(0,0,0,0.3)',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    textAlign: 'center',
};

const inputStyle = {
    width: '100%',
    padding: '10px',
    fontSize: '16px',
    borderRadius: '5px',
    border: '1px solid #ccc',
    marginBottom: '10px',
};

const saveButtonStyle = {
    padding: '8px 16px',
    backgroundColor: '#28a745',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
};

const cancelButtonStyle = {
    padding: '8px 16px',
    backgroundColor: '#6c757d',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
};

export default Manufacturer;
