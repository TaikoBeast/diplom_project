import { useState } from "react";
import { useNavigate } from "react-router-dom";

function Login() {
    const [login, setLogin] = useState(""); // было email
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError("");

        try {
            const response = await fetch("http://localhost:5000/login", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ login, password }),
            });

            const data = await response.json();

            if (response.ok) {
                localStorage.setItem("username", data.user.name);
                navigate("/dashboard");
            } else {
                setError(data.error);
            }
        } catch (err) {
            console.error("Ошибка сервера", err);
            setError("Ошибка подключения к серверу");
        }
    };

    return (
        <div style={containerStyle}>
            <div style={overlayStyle}></div>
            <div style={contentWrapperStyle}>
                <h1 style={mainTitleStyle}>Автоматизація робочого місця метролога</h1>
                <div style={formWrapperStyle}>
                    <h2 style={titleStyle}>Вхід на сайт</h2>
                    <form onSubmit={handleSubmit} style={formStyle}>
                        <input
                            type="text"
                            placeholder="Логін"
                            value={login}
                            onChange={(e) => setLogin(e.target.value)}
                            style={inputStyle}
                        />
                        <input
                            type="password"
                            placeholder="Пароль"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            style={inputStyle}
                        />
                        <button type="submit" style={buttonStyle}>Увійти</button>
                        {error && <p style={{ color: "red", marginTop: "10px" }}>{error}</p>}
                    </form>
                </div>
            </div>
        </div>
    );
}


const containerStyle = {
    height: "100vh",
    width: "100vw",
    backgroundColor: "#B87333", // более светлый коричневый
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    position: "relative",
    flexDirection: "column",
};


const overlayStyle = {
    position: "absolute",
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
    backgroundColor: "rgba(0, 0, 0, 0.3)", // небольшой затемнённый слой
    zIndex: 0,
};

const contentWrapperStyle = {
    position: "relative",
    zIndex: 1,
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
};

const mainTitleStyle = {
    color: "#fff",
    fontSize: "28px",
    fontWeight: "bold",
    marginBottom: "25px",
    textAlign: "center",
    textShadow: "1px 1px 3px rgba(0,0,0,0.7)",
};

const formWrapperStyle = {
    backgroundColor: "white",
    padding: "30px",
    borderRadius: "16px",
    boxShadow: "0 8px 16px rgba(0, 0, 0, 0.4)",
    minWidth: "320px",
};

const titleStyle = {
    marginBottom: "20px",
    fontSize: "22px",
    fontWeight: "bold",
    textAlign: "center",
};

const formStyle = {
    display: "flex",
    flexDirection: "column",
    width: "100%",
    gap: "10px",
};

const inputStyle = {
    padding: "10px",
    fontSize: "16px",
    borderRadius: "8px",
    border: "1px solid #ccc",
};

const buttonStyle = {
    padding: "10px",
    fontSize: "16px",
    backgroundColor: "#4CAF50",
    color: "white",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
};

export default Login;