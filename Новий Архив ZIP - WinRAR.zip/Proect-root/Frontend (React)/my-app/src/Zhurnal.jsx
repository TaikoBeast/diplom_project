import React from "react";

function Zhurnal() {
    return (
        <div style={{ padding: "20px" }}>
            <h1>Журнал</h1>
            <p>Тут будет журнал планирования.</p>
        </div>
    );
}

export default Zhurnal;
