import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom'; // <--- добавь это
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
    <React.StrictMode>
        <BrowserRouter>   {/* оборачиваем App в Router */}
            <App />
        </BrowserRouter>
    </React.StrictMode>
);
