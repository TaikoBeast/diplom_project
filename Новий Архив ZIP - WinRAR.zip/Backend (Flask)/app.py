from flask import Flask, request, jsonify
from flask_cors import CORS
import psycopg2
import psycopg2.extras

app = Flask(__name__)
CORS(app, supports_credentials=True)

# Подключение к БД
def get_db_connection():
    return psycopg2.connect(
        host="localhost",
        port="4123",
        database="postgres",
        user="postgres",
        password="2254"
    )

# 🔐 Авторизация
@app.route('/login', methods=['POST'])
def login():
    try:
        data = request.get_json() if request.is_json else request.form
        login = data.get('login')
        password = data.get('password')

        if not login or not password:
            return jsonify({'error': 'Логин и пароль обязательны'}), 400

        conn = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
        cursor.execute('SELECT * FROM public.emp WHERE login = %s AND pwd = %s', (login, password))
        user = cursor.fetchone()
        conn.close()

        if user:
            return jsonify({
                'message': 'Успешный вход',
                'user': {
                    'id': user['id'],
                    'login': user['login'],
                    'name': user['name']
                }
            }), 200
        else:
            return jsonify({'error': 'Неверный логин или пароль'}), 401
    except Exception as e:
        return jsonify({'error': f'Ошибка сервера: {str(e)}'}), 500

# ===== CRUD для vid_izm =====

@app.route('/sel_vid_izm', methods=['GET'])
def get_vid_izm():
    conn = get_db_connection()
    cursor = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    cursor.execute('SELECT id, name_f, name_s, note FROM "ARM".vid_izm')
    rows = cursor.fetchall()
    conn.close()

    return jsonify([
        {
            'id': row['id'],
            'name_full': row['name_f'],
            'name_short': row['name_s'],
            'note': row['note']
        }
        for row in rows
    ])

@app.route('/add_vid_izm', methods=['POST'])
def add_vid_izm():
    try:
        data = request.get_json()
        short_name = data.get('shortName')
        full_name = data.get('fullName')
        note = data.get('note')

        if not short_name or not full_name:
            return jsonify({'error': 'Обязательные поля не заполнены'}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO "ARM".vid_izm (name_s, name_f, note)
            VALUES (%s, %s, %s)
        ''', (short_name, full_name, note))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Успешно добавлено'}), 201
    except Exception as e:
        return jsonify({'error': 'Ошибка сервера'}), 500

@app.route('/update_vid_izm/<int:unit_id>', methods=['PUT'])
def update_vid_izm(unit_id):
    try:
        data = request.get_json()
        short_name = data.get('shortName')
        full_name = data.get('fullName')
        note = data.get('note')

        if not short_name or not full_name:
            return jsonify({'error': 'Поля обязательны'}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE "ARM".vid_izm
            SET name_s = %s, name_f = %s, note = %s
            WHERE id = %s
        ''', (short_name, full_name, note, unit_id))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Успешно обновлено'}), 200
    except Exception as e:
        return jsonify({'error': 'Ошибка сервера'}), 500

@app.route('/delete_vid_izm/<int:unit_id>', methods=['DELETE'])
def delete_vid_izm(unit_id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM "ARM".vid_izm WHERE id = %s', (unit_id,))
        conn.commit()
        conn.close()
        return jsonify({'message': 'Удалено'}), 200
    except Exception as e:
        return jsonify({'error': 'Ошибка сервера'}), 500

# ===== CRUD для ed_izm =====

@app.route('/sel_ed_izm', methods=['GET'])
def get_ed_izm():
    conn = get_db_connection()
    cursor = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    cursor.execute('SELECT id, name_f, name_s, note FROM "ARM".ed_izm')
    rows = cursor.fetchall()
    conn.close()

    return jsonify([
        {
            'id': row['id'],
            'name_full': row['name_f'],
            'name_short': row['name_s'],
            'note': row['note']
        }
        for row in rows
    ])

@app.route('/add_ed_izm', methods=['POST'])
def add_ed_izm():
    try:
        data = request.get_json()
        short_name = data.get('shortName')
        full_name = data.get('fullName')
        note = data.get('note')

        if not short_name or not full_name:
            return jsonify({'error': 'Обязательные поля не заполнены'}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO "ARM".ed_izm (name_s, name_f, note)
            VALUES (%s, %s, %s)
        ''', (short_name, full_name, note))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Успешно добавлено'}), 201
    except Exception as e:
        return jsonify({'error': 'Ошибка сервера'}), 500

@app.route('/update_ed_izm/<int:unit_id>', methods=['PUT'])
def update_ed_izm(unit_id):
    try:
        data = request.get_json()
        short_name = data.get('shortName')
        full_name = data.get('fullName')
        note = data.get('note')

        if not short_name or not full_name:
            return jsonify({'error': 'Поля обязательны'}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE "ARM".ed_izm
            SET name_s = %s, name_f = %s, note = %s
            WHERE id = %s
        ''', (short_name, full_name, note, unit_id))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Успешно обновлено'}), 200
    except Exception as e:
        return jsonify({'error': 'Ошибка сервера'}), 500

@app.route('/delete_ed_izm/<int:unit_id>', methods=['DELETE'])
def delete_ed_izm(unit_id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM "ARM".ed_izm WHERE id = %s', (unit_id,))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Удалено'}), 200
    except Exception as e:
        return jsonify({'error': 'Ошибка сервера'}), 500


# ===== CRUD для employees =====

@app.route('/sel_employees')
def sel_employees():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            select e.id, s.name_f name_serves, pp.name_f name_person, e.date_admission, e.date_termination, e.login, e.password FROM "ARM".employees e 
	        join "ARM".service s  on s.id = e.kod_service
	        join "ARM".physical_person pp on pp.id = e.physical_person
        ''')
        rows = cursor.fetchall()
        conn.close()

        employees = [
            {
                'id': row[0],
                'name_serves': row[1],
                'name_person': row[2],
                'date_admission': row[3].isoformat() if row[3] else None,
                'date_termination': row[4].isoformat() if row[4] else None,
                'login': row[5]
            }
            for row in rows
        ]

        return jsonify(employees)
    except Exception as e:
        print(f"❌ Помилка отримання працівників: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500

@app.route('/add_employees', methods=['POST'])
def add_employees():
    try:
        data = request.get_json()
        kod_service = data.get('kod_service')
        physical_person = data.get('physical_person')
        date_admission = data.get('hireDate')
        date_termination = data.get('dismissalDate')
        login = data.get('login')

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO "ARM".employees (kod_service, physical_person, date_admission, date_termination, login)
            VALUES (%s, %s, %s, %s, %s)
        ''', (kod_service, physical_person, date_admission, date_termination, login))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Працівника додано'}), 201
    except Exception as e:
        print(f"❌ Помилка при додаванні працівника: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500

@app.route('/update_employees/<int:id>', methods=['PUT'])
def update_employees(id):
    try:
        data = request.get_json()
        kod_service = data.get('kod_service')
        physical_person = data.get('physical_person')
        date_admission = data.get('hireDate')
        date_termination = data.get('dismissalDate')
        login = data.get('login')

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE "ARM".employees
            SET kod_service = %s,
                physical_person = %s,
                date_admission = %s,
                date_termination = %s,
                login = %s
            WHERE id = %s
        ''', (kod_service, physical_person, date_admission, date_termination, login, id))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Працівника оновлено'}), 200
    except Exception as e:
        print(f"❌ Помилка при оновленні працівника: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500

@app.route('/delete_employees/<int:id>', methods=['DELETE'])
def delete_employees(id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM "ARM".employees WHERE id = %s', (id,))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Працівника видалено'}), 200
    except Exception as e:
        print(f"❌ Помилка при видаленні працівника: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500





# ===== CRUD для services =====

@app.route('/sel_service')
def sel_services():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            select s.id, s.name_f, e.name_f kod_fk_enterpise, s.note 
            FROM "ARM".service s
            join "ARM".enterprise e on e.id = s.kod_fk_enterpise 
        ''')
        rows = cursor.fetchall()
        conn.close()

        services = [{
            'id': row[0],
            'name_f': row[1],
            'kod_fk_enterpise': row[2],
            'note': row[3]
        } for row in rows]

        return jsonify(services)
    except Exception as e:
        print(f"❌ Помилка отримання сервісів: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500




@app.route('/add_services', methods=['POST'])
def add_services():
    try:
        data = request.get_json()
        full_name = data.get('fullName')
        short_name = data.get('shortName')
        note = data.get('note')

        if not full_name or not short_name:
            return jsonify({'error': 'Обов’язкові поля не заповнені'}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO "ARM".services (full_name, short_name, note)
            VALUES (%s, %s, %s)
        ''', (full_name, short_name, note))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Сервіс додано'}), 201
    except Exception as e:
        print(f"❌ Помилка при додаванні сервісу: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500


@app.route('/update_services/<int:service_id>', methods=['PUT'])
def update_services(service_id):
    try:
        data = request.get_json()
        full_name = data.get('fullName')
        short_name = data.get('shortName')
        note = data.get('note')

        if not full_name or not short_name:
            return jsonify({'error': 'Обов’язкові поля не заповнені'}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE "ARM".services
            SET full_name = %s,
                short_name = %s,
                note = %s
            WHERE id = %s
        ''', (full_name, short_name, note, service_id))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Сервіс оновлено'}), 200
    except Exception as e:
        print(f"❌ Помилка при оновленні сервісу: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500


@app.route('/delete_services/<int:service_id>', methods=['DELETE'])
def delete_services(service_id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM "ARM".services WHERE id = %s', (service_id,))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Сервіс видалено'}), 200
    except Exception as e:
        print(f"❌ Помилка при видаленні сервісу: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500



# ===== CRUD для enterprise =====

from flask import request, jsonify

@app.route('/sel_enterprises')
def sel_enterprises():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT id, name_f, address, email, mobile, note
            FROM "ARM".enterprise
        ''')
        rows = cursor.fetchall()
        conn.close()

        enterprises = [
            {
                'id': row[0],
                'name_f': row[1],
                'address': row[2],
                'email': row[3],
                'mobile': row[4],
                'note': row[5] or ''
            }
            for row in rows
        ]

        return jsonify(enterprises)
    except Exception as e:
        print(f"❌ Помилка отримання enterprise: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500


@app.route('/add_enterprise', methods=['POST'])
def add_enterprise():
    try:
        data = request.get_json()
        name = data.get('name')
        address = data.get('address')
        email = data.get('email')
        mobile = data.get('mobile')
        note = data.get('note')

        if not name or not address:
            return jsonify({'error': 'Поля "Назва" та "Адреса" обов’язкові'}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO "ARM".enterprise (name_f, address, email, mobile, note)
            VALUES (%s, %s, %s, %s, %s)
        ''', (name, address, email, mobile, note))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Підприємство додано'}), 201
    except Exception as e:
        print(f"❌ Помилка додавання enterprise: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500


@app.route('/update_enterprise/<int:id>', methods=['PUT'])
def update_enterprise(id):
    try:
        data = request.get_json()
        name = data.get('name')
        address = data.get('address')
        email = data.get('email')
        mobile = data.get('mobile')
        note = data.get('note')

        if not name or not address:
            return jsonify({'error': 'Поля "Назва" та "Адреса" обов’язкові'}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE "ARM".enterprise
            SET name_f = %s,
                address = %s,
                email = %s,
                mobile = %s,
                note = %s
            WHERE id = %s
        ''', (name, address, email, mobile, note, id))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Підприємство оновлено'})
    except Exception as e:
        print(f"❌ Помилка оновлення enterprise: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500


@app.route('/delete_enterprise/<int:id>', methods=['DELETE'])
def delete_enterprise(id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM "ARM".enterprise WHERE id = %s', (id,))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Підприємство видалено'})
    except Exception as e:
        print(f"❌ Помилка видалення enterprise: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500



# ===== CRUD для virobnik (manufacturer) =====

@app.route('/sel_manufacturers')
def sel_manufacturers():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT id, name_f, name_address, name_mob_tel, "name_e-mail", note
            FROM "ARM".virobnik
        ''')
        rows = cursor.fetchall()
        conn.close()

        manufacturers = [
            {
                'id': row[0],
                'name': row[1],
                'address': row[2],
                'phone': row[3],
                'email': row[4],
                'note': row[5]
            } for row in rows
        ]

        return jsonify(manufacturers)
    except Exception as e:
        print(f"❌ Помилка отримання виробників: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500

@app.route('/add_manufacturer', methods=['POST'])
def add_manufacturer():
    try:
        data = request.get_json()
        name = data.get('name')
        address = data.get('address')
        phone = data.get('phone')
        email = data.get('email')
        note = data.get('note')

        if not name:
            return jsonify({'error': 'Поле "Назва" обов’язкове'}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO "ARM".virobnik (name_f, name_address, name_mob_tel, "name_e-mail", note)
            VALUES (%s, %s, %s, %s, %s)
        ''', (name, address, phone, email, note))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Виробника додано'}), 201
    except Exception as e:
        print(f"❌ Помилка при додаванні виробника: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500

@app.route('/update_manufacturer/<int:manufacturer_id>', methods=['PUT'])
def update_manufacturer(manufacturer_id):
    try:
        data = request.get_json()
        name = data.get('name')
        address = data.get('address')
        phone = data.get('phone')
        email = data.get('email')
        note = data.get('note')

        if not name:
            return jsonify({'error': 'Поле "Назва" обов’язкове'}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE "ARM".virobnik
            SET name_f = %s,
                name_address = %s,
                name_mob_tel = %s,
                "name_e-mail" = %s,
                note = %s
            WHERE id = %s
        ''', (name, address, phone, email, note, manufacturer_id))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Виробника оновлено'}), 200
    except Exception as e:
        print(f"❌ Помилка при оновленні виробника: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500

@app.route('/delete_manufacturer/<int:manufacturer_id>', methods=['DELETE'])
def delete_manufacturer(manufacturer_id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM "ARM".virobnik WHERE id = %s', (manufacturer_id,))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Виробника видалено'}), 200
    except Exception as e:
        print(f"❌ Помилка при видаленні виробника: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500




# ===== CRUD для class =====

@app.route('/sel_accuracy_class')
def sel_accuracy_class():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT id, name_f, note
            FROM "ARM"."class"
        ''')
        rows = cursor.fetchall()
        conn.close()

        classes = [
            {
                'id': row[0],
                'name': row[1],
                'note': row[2]
            } for row in rows
        ]

        return jsonify(classes)
    except Exception as e:
        print(f"❌ Помилка отримання класів точності: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500

@app.route('/add_accuracy_class', methods=['POST'])
def add_accuracy_class():
    try:
        data = request.get_json()
        name = data.get('name')
        note = data.get('note')

        if not name:
            return jsonify({'error': 'Поле "Назва" обов’язкове'}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO "ARM"."class" (name_f, note)
            VALUES (%s, %s)
        ''', (name, note))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Клас додано'}), 201
    except Exception as e:
        print(f"❌ Помилка при додаванні класу: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500

@app.route('/update_accuracy_class/<int:class_id>', methods=['PUT'])
def update_accuracy_class(class_id):
    try:
        data = request.get_json()
        name = data.get('name')
        note = data.get('note')

        if not name:
            return jsonify({'error': 'Поле "Назва" обов’язкове'}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE "ARM"."class"
            SET name_f = %s,
                note = %s
            WHERE id = %s
        ''', (name, note, class_id))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Клас оновлено'}), 200
    except Exception as e:
        print(f"❌ Помилка при оновленні класу: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500

@app.route('/delete_accuracy_class/<int:class_id>', methods=['DELETE'])
def delete_accuracy_class(class_id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM "ARM"."class" WHERE id = %s', (class_id,))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Клас видалено'}), 200
    except Exception as e:
        print(f"❌ Помилка при видаленні класу: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500



# ===== CRUD для physical_person =====

@app.route('/sel_physical_persons')
def sel_physical_persons():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT id, name_f, address, mobile, note
            FROM "ARM".physical_person
        ''')
        rows = cursor.fetchall()
        conn.close()

        persons = [
            {
                'id': row[0],
                'fullName': row[1],
                'address': row[2],
                'phone': row[3],
                'note': row[4]
            } for row in rows
        ]

        return jsonify(persons)
    except Exception as e:
        print(f"❌ Помилка отримання фізичних осіб: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500

@app.route('/add_physical_person', methods=['POST'])
def add_physical_person():
    try:
        data = request.get_json()
        fullName = data.get('fullName')
        address = data.get('address')
        phone = data.get('phone')
        note = data.get('note')

        if not fullName:
            return jsonify({'error': 'Поле ПІБ обов’язкове'}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO "ARM".physical_person (name_f, address, mobile, note)
            VALUES (%s, %s, %s, %s)
        ''', (fullName, address, phone, note))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Фізичну особу додано'}), 201
    except Exception as e:
        print(f"❌ Помилка при додаванні фізичної особи: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500

@app.route('/update_physical_person/<int:person_id>', methods=['PUT'])
def update_physical_person(person_id):
    try:
        data = request.get_json()
        fullName = data.get('fullName')
        address = data.get('address')
        phone = data.get('phone')
        note = data.get('note')

        if not fullName:
            return jsonify({'error': 'Поле ПІБ обов’язкове'}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE "ARM".physical_person
            SET name_f = %s,
                address = %s,
                mobile = %s,
                note = %s
            WHERE id = %s
        ''', (fullName, address, phone, note, person_id))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Фізичну особу оновлено'}), 200
    except Exception as e:
        print(f"❌ Помилка при оновленні фізичної особи: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500

@app.route('/delete_physical_person/<int:person_id>', methods=['DELETE'])
def delete_physical_person(person_id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM "ARM".physical_person WHERE id = %s', (person_id,))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Фізичну особу видалено'}), 200
    except Exception as e:
        print(f"❌ Помилка при видаленні фізичної особи: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500




# ===== CRUD для settings =====

@app.route('/sel_settings')
def sel_settings():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT id, name_f, note
            FROM "ARM".settings
        ''')
        rows = cursor.fetchall()
        conn.close()

        settings = [
            {
                'id': row[0],
                'name': row[1],
                'note': row[2]
            } for row in rows
        ]

        return jsonify(settings)
    except Exception as e:
        print(f"❌ Помилка отримання параметрів: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500

@app.route('/add_setting', methods=['POST'])
def add_setting():
    try:
        data = request.get_json()
        name = data.get('name')
        note = data.get('note')

        if not name:
            return jsonify({'error': 'Поле "Наименование" обов’язкове'}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO "ARM".settings (name_f, note)
            VALUES (%s, %s)
        ''', (name, note))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Параметр додано'}), 201
    except Exception as e:
        print(f"❌ Помилка при додаванні параметра: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500

@app.route('/update_setting/<int:setting_id>', methods=['PUT'])
def update_setting(setting_id):
    try:
        data = request.get_json()
        name = data.get('name')
        note = data.get('note')

        if not name:
            return jsonify({'error': 'Поле "Наименование" обов’язкове'}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE "ARM".settings
            SET name_f = %s,
                note = %s
            WHERE id = %s
        ''', (name, note, setting_id))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Параметр оновлено'}), 200
    except Exception as e:
        print(f"❌ Помилка при оновленні параметра: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500

@app.route('/delete_setting/<int:setting_id>', methods=['DELETE'])
def delete_setting(setting_id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM "ARM".settings WHERE id = %s', (setting_id,))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Параметр видалено'}), 200
    except Exception as e:
        print(f"❌ Помилка при видаленні параметра: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500



# ===== CRUD для stats =====

@app.route('/sel_stats')
def sel_stats():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT id, name_f, note
            FROM "ARM".stats
        ''')
        rows = cursor.fetchall()
        conn.close()

        stats = [
            {
                'id': row[0],
                'name': row[1],
                'note': row[2]
            } for row in rows
        ]

        return jsonify(stats)
    except Exception as e:
        print(f"❌ Помилка отримання статусів: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500

@app.route('/add_stat', methods=['POST'])
def add_stat():
    try:
        data = request.get_json()
        name = data.get('name')
        note = data.get('note')

        if not name:
            return jsonify({'error': 'Поле "Наименование" обов’язкове'}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO "ARM".stats (name_f, note)
            VALUES (%s, %s)
        ''', (name, note))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Статус додано'}), 201
    except Exception as e:
        print(f"❌ Помилка при додаванні статусу: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500

@app.route('/update_stat/<int:stat_id>', methods=['PUT'])
def update_stat(stat_id):
    try:
        data = request.get_json()
        name = data.get('name')
        note = data.get('note')

        if not name:
            return jsonify({'error': 'Поле "Наименование" обов’язкове'}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE "ARM".stats
            SET name_f = %s,
                note = %s
            WHERE id = %s
        ''', (name, note, stat_id))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Статус оновлено'}), 200
    except Exception as e:
        print(f"❌ Помилка при оновленні статусу: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500

@app.route('/delete_stat/<int:stat_id>', methods=['DELETE'])
def delete_stat(stat_id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM "ARM".stats WHERE id = %s', (stat_id,))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Статус видалено'}), 200
    except Exception as e:
        print(f"❌ Помилка при видаленні статусу: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500





# ===== CRUD для category =====

@app.route('/sel_categories')
def sel_categories():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT id, name_f, note
            FROM "ARM".category
        ''')
        rows = cursor.fetchall()
        conn.close()

        categories = [
            {
                'id': row[0],
                'name': row[1],
                'note': row[2]
            } for row in rows
        ]

        return jsonify(categories)
    except Exception as e:
        print(f"❌ Помилка отримання категорій: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500

@app.route('/add_category', methods=['POST'])
def add_category():
    try:
        data = request.get_json()
        name = data.get('name')
        note = data.get('note')

        if not name:
            return jsonify({'error': 'Поле "Наименование" обов’язкове'}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO "ARM".category (name_f, note)
            VALUES (%s, %s)
        ''', (name, note))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Категорію додано'}), 201
    except Exception as e:
        print(f"❌ Помилка при додаванні категорії: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500

@app.route('/update_category/<int:category_id>', methods=['PUT'])
def update_category(category_id):
    try:
        data = request.get_json()
        name = data.get('name')
        note = data.get('note')

        if not name:
            return jsonify({'error': 'Поле "Наименование" обов’язкове'}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE "ARM".category
            SET name_f = %s,
                note = %s
            WHERE id = %s
        ''', (name, note, category_id))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Категорію оновлено'}), 200
    except Exception as e:
        print(f"❌ Помилка при оновленні категорії: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500

@app.route('/delete_category/<int:category_id>', methods=['DELETE'])
def delete_category(category_id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM "ARM".category WHERE id = %s', (category_id,))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Категорію видалено'}), 200
    except Exception as e:
        print(f"❌ Помилка при видаленні категорії: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500





# ===== CRUD для vid_povirki =====

@app.route('/sel_vid_povirki')
def sel_vid_povirki():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT id, name_f, note
            FROM "ARM".vid_povirki
        ''')
        rows = cursor.fetchall()
        conn.close()

        data = [
            {
                'id': row[0],
                'name': row[1],
                'note': row[2]
            } for row in rows
        ]

        return jsonify(data)
    except Exception as e:
        print(f"❌ Помилка отримання видів повірки: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500

@app.route('/add_vid_povirki', methods=['POST'])
def add_vid_povirki():
    try:
        data = request.get_json()
        name = data.get('name')
        note = data.get('note')

        if not name:
            return jsonify({'error': 'Поле "Назва" обов’язкове'}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO "ARM".vid_povirki (name_f, note)
            VALUES (%s, %s)
        ''', (name, note))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Вид повірки додано'}), 201
    except Exception as e:
        print(f"❌ Помилка при додаванні виду повірки: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500

@app.route('/update_vid_povirki/<int:item_id>', methods=['PUT'])
def update_vid_povirki(item_id):
    try:
        data = request.get_json()
        name = data.get('name')
        note = data.get('note')

        if not name:
            return jsonify({'error': 'Поле "Назва" обов’язкове'}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE "ARM".vid_povirki
            SET name_f = %s,
                note = %s
            WHERE id = %s
        ''', (name, note, item_id))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Вид повірки оновлено'}), 200
    except Exception as e:
        print(f"❌ Помилка при оновленні виду повірки: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500

@app.route('/delete_vid_povirki/<int:item_id>', methods=['DELETE'])
def delete_vid_povirki(item_id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM "ARM".vid_povirki WHERE id = %s', (item_id,))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Вид повірки видалено'}), 200
    except Exception as e:
        print(f"❌ Помилка при видаленні виду повірки: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500







# ===== CRUD для mist_povirki =====

from flask import request, jsonify

@app.route('/sel_mist_povirki')
def sel_mist_povirki():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT id, name_f, note
            FROM "ARM".mist_povirki
        ''')
        rows = cursor.fetchall()
        conn.close()

        mist_list = [
            {'id': row[0], 'name_f': row[1], 'note': row[2] or ''}
            for row in rows
        ]

        return jsonify(mist_list)
    except Exception as e:
        print(f"❌ Помилка отримання mist_povirki: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500


@app.route('/add_mist_povirki', methods=['POST'])
def add_mist_povirki():
    try:
        data = request.get_json()
        name = data.get('name_f')
        note = data.get('note')

        if not name:
            return jsonify({'error': 'Поле Назва обов’язкове'}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO "ARM".mist_povirki (name_f, note)
            VALUES (%s, %s)
        ''', (name, note))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Запис додано'}), 201
    except Exception as e:
        print(f"❌ Помилка додавання mist_povirki: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500


@app.route('/update_mist_povirki/<int:id>', methods=['PUT'])
def update_mist_povirki(id):
    try:
        data = request.get_json()
        name = data.get('name_f')
        note = data.get('note')

        if not name:
            return jsonify({'error': 'Поле Назва обов’язкове'}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE "ARM".mist_povirki
            SET name_f = %s, note = %s
            WHERE id = %s
        ''', (name, note, id))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Запис оновлено'})
    except Exception as e:
        print(f"❌ Помилка оновлення mist_povirki: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500


@app.route('/delete_mist_povirki/<int:id>', methods=['DELETE'])
def delete_mist_povirki(id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM "ARM".mist_povirki WHERE id = %s', (id,))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Запис видалено'})
    except Exception as e:
        print(f"❌ Помилка видалення mist_povirki: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500






# ===== CRUD для metod_povirki =====

from flask import request, jsonify

@app.route('/sel_metod_povirki')
def sel_metod_povirki():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT id, name_f, note
            FROM "ARM".metod_povirki
        ''')
        rows = cursor.fetchall()
        conn.close()

        metods = [
            {'id': row[0], 'name_f': row[1], 'note': row[2] or ''}
            for row in rows
        ]

        return jsonify(metods)
    except Exception as e:
        print(f"❌ Помилка отримання metod_povirki: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500


@app.route('/add_metod_povirki', methods=['POST'])
def add_metod_povirki():
    try:
        data = request.get_json()
        name = data.get('name_f')
        note = data.get('note')

        if not name:
            return jsonify({'error': 'Поле "Назва" обов’язкове'}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO "ARM".metod_povirki (name_f, note)
            VALUES (%s, %s)
        ''', (name, note))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Метод додано'}), 201
    except Exception as e:
        print(f"❌ Помилка додавання metod_povirki: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500


@app.route('/update_metod_povirki/<int:id>', methods=['PUT'])
def update_metod_povirki(id):
    try:
        data = request.get_json()
        name = data.get('name_f')
        note = data.get('note')

        if not name:
            return jsonify({'error': 'Поле "Назва" обов’язкове'}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE "ARM".metod_povirki
            SET name_f = %s, note = %s
            WHERE id = %s
        ''', (name, note, id))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Метод оновлено'})
    except Exception as e:
        print(f"❌ Помилка оновлення metod_povirki: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500


@app.route('/delete_metod_povirki/<int:id>', methods=['DELETE'])
def delete_metod_povirki(id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM "ARM".metod_povirki WHERE id = %s', (id,))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Метод видалено'})
    except Exception as e:
        print(f"❌ Помилка видалення metod_povirki: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500




# ===== CRUD для location_si =====

from flask import request, jsonify

@app.route('/sel_location_si')
def sel_location_si():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT id, name_f, note
            FROM "ARM".location_si
        ''')
        rows = cursor.fetchall()
        conn.close()

        locations = [
            {'id': row[0], 'name_f': row[1], 'note': row[2] or ''}
            for row in rows
        ]

        return jsonify(locations)
    except Exception as e:
        print(f"❌ Помилка отримання location_si: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500


@app.route('/add_location_si', methods=['POST'])
def add_location_si():
    try:
        data = request.get_json()
        name = data.get('name_f')
        note = data.get('note')

        if not name:
            return jsonify({'error': 'Поле "Назва" обов’язкове'}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO "ARM".location_si (name_f, note)
            VALUES (%s, %s)
        ''', (name, note))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Місце розташування додано'}), 201
    except Exception as e:
        print(f"❌ Помилка додавання location_si: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500


@app.route('/update_location_si/<int:id>', methods=['PUT'])
def update_location_si(id):
    try:
        data = request.get_json()
        name = data.get('name_f')
        note = data.get('note')

        if not name:
            return jsonify({'error': 'Поле "Назва" обов’язкове'}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE "ARM".location_si
            SET name_f = %s, note = %s
            WHERE id = %s
        ''', (name, note, id))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Місце розташування оновлено'})
    except Exception as e:
        print(f"❌ Помилка оновлення location_si: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500


@app.route('/delete_location_si/<int:id>', methods=['DELETE'])
def delete_location_si(id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM "ARM".location_si WHERE id = %s', (id,))
        conn.commit()
        conn.close()

        return jsonify({'message': 'Місце розташування видалено'})
    except Exception as e:
        print(f"❌ Помилка видалення location_si: {e}")
        return jsonify({'error': 'Помилка сервера'}), 500




# ===== CRUD для vvod_ekspluat =====

@app.route('/documents_vvod_ekspluat')
def get_documents_vvod_ekspluat():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Получаем id типа документа "Ввод в експлуатацію"
        cursor.execute('SELECT id FROM "ARM".tip_doc WHERE name_f = %s', ('Ввод в експлуатацію',))
        tip_doc_id = cursor.fetchone()[0]

        cursor.execute('''
            SELECT d.id, d.date_doc, d.n_doc,
                   pp.name_f, mi.factory_number, mi.inventory_number,
                   ls.name_f, mp.name_f, mp2.name_f, vp.name_f, s.name_f
            FROM "ARM".documents d
            JOIN "ARM".physical_person pp ON pp.id = d.physical_person
            JOIN "ARM".measuring_instrument mi ON mi.id = d.measuring_instrument
            JOIN "ARM".location_si ls ON ls.id = d.location_si
            JOIN "ARM".metod_povirki mp ON mp.id = d.metod_povirki
            JOIN "ARM".mist_povirki mp2 ON mp2.id = d.mist_povirki
            JOIN "ARM".vid_povirki vp ON vp.id = d.vid_povirki
            JOIN "ARM".stats s ON s.id = d.stats
            WHERE d.tip_doc = %s
        ''', (tip_doc_id,))

        rows = cursor.fetchall()
        conn.close()

        return jsonify([
            {
                'id': r[0], 'date_doc': r[1].isoformat() if r[1] else None, 'n_doc': r[2],
                'fullname': r[3], 'factory_number': r[4], 'inventory_number': r[5],
                'name_location_si': r[6], 'name_metod_povirki': r[7],
                'name_mist_povirki': r[8], 'name_vid_povirki': r[9], 'name_stats': r[10]
            } for r in rows
        ])
    except Exception as e:
        print(f"❌ Error: {e}")
        return jsonify({'error': 'server error'}), 500


# Добавление документа
@app.route('/add_document', methods=['POST'])
def add_document():
    try:
        data = request.get_json()

        # Получаем ID типа документа "Ввод в експлуатацію"
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT id FROM "ARM".tip_doc WHERE name_f = %s', ('Ввод в експлуатацію',))
        tip_doc_id = cursor.fetchone()[0]

        cursor.execute('''
            INSERT INTO "ARM".documents
            (date_doc, n_doc, physical_person, measuring_instrument,
             tip_doc, location_si, metod_povirki, mist_povirki, vid_povirki, stats)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
        ''', (
            data['date_doc'], data['n_doc'], data['physical_person'], data['measuring_instrument'],
            tip_doc_id, data['location_si'], data['metod_povirki'],
            data['mist_povirki'], data['vid_povirki'], data['stats']
        ))
        conn.commit()
        conn.close()
        return jsonify({'message': 'Документ додано'}), 201
    except Exception as e:
        print(f"❌ Error adding document: {e}")
        return jsonify({'error': 'server error'}), 500


# Обновление документа
@app.route('/update_document/<int:id>', methods=['PUT'])
def update_document(id):
    try:
        data = request.get_json()
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE "ARM".documents SET
            date_doc=%s, n_doc=%s, physical_person=%s, measuring_instrument=%s,
            location_si=%s, metod_povirki=%s, mist_povirki=%s, vid_povirki=%s, stats=%s
            WHERE id = %s
        ''', (
            data['date_doc'], data['n_doc'], data['physical_person'], data['measuring_instrument'],
            data['location_si'], data['metod_povirki'], data['mist_povirki'], data['vid_povirki'],
            data['stats'], id
        ))
        conn.commit()
        conn.close()
        return jsonify({'message': 'Оновлено'}), 200
    except Exception as e:
        print(f"❌ Error updating: {e}")
        return jsonify({'error': 'server error'}), 500


if __name__ == '__main__':
    app.run(debug=True)
